var user = require("./user/index.js")
module.exports = app => {
    app.use('/user',user)
}