
var Role = require('./controll');
const express = require('express');
const router = express.Router();
router.post('/role',Role.post);
router.delete('/role',Role.delete);
router.put('/role',Role.put);
router.get('/role',Role.get);
module.exports = router;
