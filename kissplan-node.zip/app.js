const express = require('express');
const fs = require('fs')
const path = require('path')
const isProd = process.env.NODE_ENV !== 'development'
const app = express();
require("./db/mongoose.js")
require("./route/index.js")(app)
const port = /*process.env.PORT ||*/ 3001
app.listen(port, () => {
  console.log(`server started at http://localhost:${port}`)
})
  