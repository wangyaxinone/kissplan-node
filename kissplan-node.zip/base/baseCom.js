class baseCom {
    constructor(){
        this.current = 1;
        this.size = 10;
    }
}
module.exports = baseCom;